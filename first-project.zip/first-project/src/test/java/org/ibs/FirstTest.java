package org.ibs;

import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class FirstTest {

    @Test
    void testRegistrationWithInvalidEmail() {
        System.setProperty("webdriver.edge.driver", "src\\test\\resources\\msedgedriver.exe");
        WebDriver driver = new EdgeDriver();
        Actions actions = new Actions(driver);
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

        try {
            // Шаг 1: Переход на страницу регистрации
            driver.get("http://217.74.37.176/?route=account/register&language=ru-ru");

            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            Thread.sleep(2000);
            actions.scrollByAmount(0, 200).perform();

            // Шаг 2: Ввод валидных значений в соответствующие поля
            WebElement input_Name = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("input-firstname")));
            input_Name.sendKeys("Иван");
            Thread.sleep(2000);

            WebElement input_Lastname = driver.findElement(By.id("input-lastname"));
            input_Lastname.sendKeys("Иванов");
            Thread.sleep(2000);

            WebElement input_password = driver.findElement(By.id("input-password"));
            input_password.sendKeys("Q1w2e3l");
            Thread.sleep(2000);

            // Включение подписки
            WebElement input_news = driver.findElement(By.id("input-newsletter"));
            input_news.click();
            Thread.sleep(2000);

            // Включение подтверждения
            WebElement input_agree= driver.findElement(By.xpath("//input[@name ='agree']"));
            input_agree.click();
            Thread.sleep(2000);

            // Шаг 3: Ввод подготовленного E-mail в поле "E-mail"
            WebElement input_email = driver.findElement(By.id("input-email"));
            input_email.sendKeys("himail.ru"); // Email без @ символа
            Thread.sleep(2000);

            // Шаг 4: Нажать на кнопку "Продолжить"
            WebElement Btnfinal = driver.findElement(By.xpath("//button[text()='Продолжить']"));
            Btnfinal.click();
            Thread.sleep(2000);

            // Проверка, что регистрация провалилась (остались на странице регистрации или появилось сообщение об ошибке)
            boolean isRegistrationFailed = driver.getCurrentUrl().contains("register") ||
                    driver.findElements(By.cssSelector(".alert-danger, .text-danger")).size() > 0;

            assertTrue(isRegistrationFailed, "Регистрация должна быть провальной из-за отсутствия @ в email");

        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        } finally {
            driver.quit();
        }
    }
}